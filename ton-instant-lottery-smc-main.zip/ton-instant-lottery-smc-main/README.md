# ton-instant-lottery-smc
####  [ton.fun](https://ton.fun) | [lotto.ton](http://lotto.ton)


contract address:\
`EQBfpjXuUSvL8q64Bg0qJHFXro1gt81LFDjNJw9ZWibC8UZK`
